<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed'); ?>

<h1>Привет</h1>
Это страница Home.php из Views...
