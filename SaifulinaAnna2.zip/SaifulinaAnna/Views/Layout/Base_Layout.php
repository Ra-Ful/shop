<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed'); ?><!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <title><?php echo $params['title'] ?></title>
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <link href="/Css/style_layout.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
    </head>
    <body>
        <header>
            <nav>
                <a id="about_button" href="<?php echo ROOT_URL; ?>/home">Обо мне</a>
                <a id="portfolio_button" href="<?php echo ROOT_URL; ?>/portfolio">Портфолио</a>
                <a id="blog_button" href="<?php echo ROOT_URL; ?>/blog">Блог</a>
            </nav>
        </header>
        <div class="main">
                <?= $body ?>
        </div>
    </body>
</html>