<h1 style="color: rgb(109, 118, 126);">Товары</h1>
<div class="towari">
<?php

    require_once ROOTPATH."/Model/Goods.php"; 
    
    $m_goods= new ModelGoods();
    $goods_list = $m_goods->getProductByGroupId($group_id);

    foreach ($goods_list as $goods) {
        ?>
        <div class="towar">
        <img src="<?php echo ROOT_SITE; ?>/Static/image/<?php echo $goods["img"]; ?>">
        <h2><?php echo htmlentities($goods["name"]); ?></h2>
        <p>Цена:<?php echo htmlentities($goods["price"]); ?>р <sub class="skidka"><strike><?php echo htmlentities($goods["price_full"]); ?>р</strike></sub></p>

        <form action="<?php echo ROOT_URL; ?>/Cart/add" method="post">
            <div class="buttons">
                <input style="display:none;" name="id" value="<?php echo htmlentities($goods["id"]); ?>">
                <input type="submit" value="В корзину">
            </div>
        </form>

       </div>

     <?php  

    }
    
?>

</div>