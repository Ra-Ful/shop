
<link rel="stylesheet" href="../Static/css/main.css">
<div class = "razdeli">
    <button onclick="document.location='<?php echo ROOT_URL; ?>/Group/view/1'">Акриловые фигурки</button>
    <button onclick="document.location='<?php echo ROOT_URL; ?>/Group/view/2'">Брелки</button>
    <button onclick="document.location='<?php echo ROOT_URL; ?>/Group/view/3'">Значки</button>
</div>