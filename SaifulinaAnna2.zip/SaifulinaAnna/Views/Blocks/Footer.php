
<link rel="stylesheet" href="../Static/css/main.css">

<footer>
<hr>
    <nav class="footer">
        <ul> 
            <a href="/SaifulinaAnna/index.php">Главная</a> <br>
           <a href="#">О нас</a> <br>
           <a href="https://socprofile.com/sokva">Контакты</a><br>

        </ul>
    </nav>
  </footer>