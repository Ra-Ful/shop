<br><br><b>Начало корзины:</b>

<?php
$products = $_SESSION["Cart"];
$total_cost = 0;
foreach ($products as $product) {
    //Дизайн корзины 
    $cost = $product["count"] * $product["price"];
    $total_cost = $total_cost + $cost;
?>
<div>
    Строка корзины:
<?php echo htmlentities($product["name"]); ?>
 id= <?php echo htmlentities($product["id"]); ?>
 Цена: <?php echo htmlentities($product["price"]); ?>
 Количество: <?php echo htmlentities($product["count"]); ?>
 Итого: <?php echo htmlentities($cost); ?>
 <form action="<?php echo ROOT_URL; ?>/Cart/delete" method="post">
            <input style="display:none;" name="id" value="<?php echo htmlentities($product["id"]); ?>">
            <input type="submit" value="Удалить">
</form>
</div>
<?php
}

?>
 <br><b>------------</b> 

<br><b>Итого в корзине:</b> <?php echo htmlentities($total_cost); ?>
 
<form action="<?php echo ROOT_URL; ?>/Cart/delete/all" method="post">
            <div class="ChistkaCorzini">
                <input style="display:none;" name="id" value="all">
                <input type="submit" value="Очистить корзину">
            </div>
</form>

