<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $html_title; ?></title>
    <link rel="stylesheet" href="<?php echo ROOT_SITE; ?>/Static/css/main.css">
    
</head>
<hr>
<header>
       <h3 style="color: rgb(253, 253, 249);">Создайте собственный мерч!</h3> 
        <div class="logo"> 
            <img class = "MoonHomeimg" id="img" src="/SaifulinaAnna/Static/image/логотип.png" alt="Логотип">
            <h4>Добро пожаловать в наш интернет магазин</h4>
        </div>
    </header>
<body>
    <br>

