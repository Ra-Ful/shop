<link rel="stylesheet" href="../Static/css/main.css">
<a class="but" href="/SaifulinaAnna/index.php/Cart/add">Корзина</a>