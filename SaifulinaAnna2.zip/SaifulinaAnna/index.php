<?php
	//Сайфулина Анна 

	//Стартовая страница - переадресация на другие
	//Мини защита позволяет присоедниять PHP, но запред на простое открытие PHP
	define('NOACCESS', 1);
	//phpinfo(); - смотреть перменные и настройки PHP
	define('ROOTPATH', __DIR__);

	define('ROOT_SITE','/SaifulinaAnna'); //Для обращений к папкам
	define('ROOT_URL',ROOT_SITE.'/index.php'); //Для ссылок на страницах
	
	$configs = include(ROOTPATH.'/App/Config.php');	

	require_once ROOTPATH.'/App/App.php';

	//Основа вызова классов заложена отсюда https://habr.com/ru/articles/320480/
	
	//Важно все классы Контроллеры должны начинаться с "Controller_{дополнительное имя}" т.к. к ним идет подключение по этому имени...

	App::init($configs);
	App::$kernel->launch();
?>