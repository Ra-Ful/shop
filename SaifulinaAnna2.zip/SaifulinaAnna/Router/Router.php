<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed');
class Router
{
    //Раскладываем URI на части...
    public function resolve_path ()
    {
        $route = null;
        if(($pos = strpos($_SERVER['REQUEST_URI'], '?')) !== false){
            $route = substr($_SERVER['REQUEST_URI'], 0, $pos);
        }
        $route = is_null($route) ? $_SERVER['REQUEST_URI'] : $route;
        $route = explode('/', $route);
        array_shift($route); 
        array_shift($route); //Вырезаем папку проекта
        array_shift($route); //Вырезаем index.php
        $result[0] = array_shift($route); //параметр после index.php - Контроллер
        $result[1] = array_shift($route); //параметр Action - действие
        $result[2] = $route; //Массив дополнительных параметров [0] = ... [1] = 

        return $result;
        
    }
    
}