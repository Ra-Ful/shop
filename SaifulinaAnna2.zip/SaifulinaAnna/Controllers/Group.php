<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed'); 

class Controller_Group extends Controller
{
    public function view($uri_params)
    {
        
        $view_params=[];
        $view_params['html_title']='Показать группу товара ';

        $html = '';
        $html.=$this->render('Blocks\Html_Start',$view_params);
        $html.=$this->render('Blocks\Groups',$view_params);
        $view_params['group_id']=$uri_params[0];
        $html.=$this->render('Goods_List',$view_params);
        $html.=$this->render('Blocks\Footer',$view_params);
        $html.=$this->render('Blocks\Html_End',$view_params);

        return $html;


        
    }
    
}