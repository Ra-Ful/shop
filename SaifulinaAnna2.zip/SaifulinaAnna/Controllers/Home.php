<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed'); 

class Controller_Home extends Controller
{
    //Вызов ... Home/index/

    public function index($uri_params)
    {
        
        $view_params=[];
        $view_params['html_title']='Главная страница';

        $html = '';
        //$html.='123';//$this->render_base_layout('Home',$view_params); //Вывести Views/Home.php в основной шаблон
        $html.=$this->render('Blocks\corzina',$view_params); 
        $html.=$this->render('Blocks\Html_Start',$view_params); 
        $html.=$this->render('Blocks\Groups',$view_params);
        $html.=$this->render('Blocks\glavnai',$view_params);
        $html.=$this->render('Blocks\Footer',$view_params);
        $html.=$this->render('Blocks\Html_End',$view_params);

        return $html;


        
    }
    
}