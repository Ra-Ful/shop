<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed'); 

require_once ROOTPATH."/Model/Goods.php"; 


class Controller_Cart extends Controller
{
    public function add($uri_params)
    {
        
        $view_params=[];
        $view_params['html_title']='Добавление товара в корзину';

        $html = '';
        $html.=$this->render('Blocks\Html_Start',$view_params);
        $html.=$this->render('Blocks\Groups',$view_params);
        
        $id = '';
        if (isset($_POST["id"])) {
            $id = $_POST["id"];
        }

        if ($id == '') {
            $html.='Не указан товар для добавления';
        }
        else
        {
            $MGoods = new ModelGoods;
            $tovar = $MGoods->getProductById($id)->fetch_assoc();
            
            //$html.='Добавление товара в корзину';
            //$html.=var_export($_SESSION["Cart"],true);

            //Добавляем товар в козину
            $product = [
                'id' => $tovar['id'],
                'name' => $tovar['name'],
                'price' => $tovar['price'],
                'count' => 1
            ];
            
            //Проверим есть ли такой товар в корзине? 
            $index = array_search($id, array_column($_SESSION["Cart"], 'id'));
            // Найден такой же товар 
            if ($index !== false) {
                //Старое количество +1 
                $count_old = $_SESSION["Cart"][$index]["count"];
                $product["count"] += $count_old;
                $_SESSION["Cart"][$index] = $product;

            } else {
                //Положим товар в корзину
                $_SESSION["Cart"][] = $product;
            }
                
           
        }
        $html.=$this->render('Blocks\Cart_List',$view_params);
        $html.=$this->render('Blocks\Footer',$view_params);
        $html.=$this->render('Blocks\Html_End',$view_params);

        return $html;
       
    }

    public function delete($uri_params)
    {
        
        $view_params=[];
        $view_params['html_title']='Удаление товара из корзины';

        $html = '';
        $html.=$this->render('Blocks\Html_Start',$view_params);
        $html.=$this->render('Blocks\Groups',$view_params);
        
        $id = '';
        if (isset($_POST["id"])) {
            $id = $_POST["id"];
        }

        $html.=var_export($id,true);


        if ($id == '') {
            $html.='Не указан товар для удаления ';
        }
        else
        {
            //Чистка всего - 
            if ($id == 'all') { $_SESSION["Cart"] = []; }  else {
                //Проверим есть ли такой товар в корзине? 
                $index = array_search($id, array_column($_SESSION["Cart"], 'id'));
                // Найден такой же товар 
                if ($index !== false) {
                    //Удаляем один элемент
                    array_splice($_SESSION["Cart"], $index, 1); // Удаляем один элемент
                }
            }
           
        }
        $html.=$this->render('Blocks\Cart_List',$view_params);
        $html.=$this->render('Blocks\Footer',$view_params);
        $html.=$this->render('Blocks\Html_End',$view_params);

        return $html;
       
    }


    
    public function index($uri_params)
    {
        
        $view_params=[];
        $view_params['html_title']='Корзина';

        $html = '';
        $html.=$this->render('Blocks\Html_Start',$view_params);
        $html.=$this->render('Blocks\Groups',$view_params);
        
        $html.=$this->render('Blocks\Cart_List',$view_params);
        $html.=$this->render('Blocks\Html_End',$view_params);

        return $html;
       
    }
    
}