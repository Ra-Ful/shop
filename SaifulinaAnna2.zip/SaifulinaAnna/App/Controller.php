<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed');

class Controller 
{
    
    public $layoutFile = 'Views/Layout.php';
    
    //Главный шаблон
    public function renderLayout ($body,array $params = []) 
    {
        extract($params);
        
        ob_start(); //Включение буфиризации вывода
        require ROOTPATH.DIRECTORY_SEPARATOR.'Views'.DIRECTORY_SEPARATOR.'Layout'.DIRECTORY_SEPARATOR."Base_Layout.php";
        return ob_get_clean(); //Получение накопленного буфера ...
                
    }
    
    //Вывод в главный шаблон
    public function render_base_layout($viewName, array $params = [])
    {
        
        $viewFile = ROOTPATH.DIRECTORY_SEPARATOR.'Views'.DIRECTORY_SEPARATOR.$viewName.'.php';

        extract($params);

        ob_start();
        require $viewFile;
        $body = ob_get_clean();
        
        if (ob_get_contents()) ob_end_clean();

        /*if (defined(NO_LAYOUT)){
            return $body;
        }*/
        return $this->renderLayout($body,$params);
    }

    //Вывод без главного шаблона
    public function render($viewName, array $params = [])
    {
        
        $viewFile = ROOTPATH.DIRECTORY_SEPARATOR.'Views'.DIRECTORY_SEPARATOR.$viewName.'.php';

        extract($params);

        ob_start();
        require $viewFile;
        $body = ob_get_clean();
        
        if (ob_get_contents()) ob_end_clean();
        
        return $body;
    }
    
}