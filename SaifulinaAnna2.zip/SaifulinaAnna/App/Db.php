<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed');

class DB  {
        public $link;
        // Подключение к db
        public function __construct($config) {
            $this->link = new mysqli($config['MYSQL_HOST'],$config['MYSQL_USER'],$config['MYSQL_PASSWORD'],$config['MYSQL_DB'],$config['MYSQL_PORT']);
            //проверка на подключения
            if ($this->link->connect_error) {
                die("Connection failed: " . $this->link->connect_error);
            }
        }

}
    