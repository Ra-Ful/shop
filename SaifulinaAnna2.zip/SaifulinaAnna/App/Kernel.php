<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed');

class Kernel 
{
    
    public $defaultControllerName = 'Home';
    
    public $defaultActionName = "index";
    
    //Запуск разных классов ...
    public function launch()
    {
        

        if(session_status() === PHP_SESSION_NONE) session_start();        

        //Создаем Козину
        if (!isset($_SESSION["Cart"])) {
            $_SESSION["Cart"] = [];        
        }

        list($controllerName, $actionName, $params) = App::$router->resolve_path();
        
        //Контроллер по умолчанию...Home ,  ucfirst() - делает первую букву Большой 
        $controllerName = empty($controllerName) ? $this->defaultControllerName : ucfirst($controllerName);

        echo $this->launchAction($controllerName, $actionName, $params);
            
    }
    

    public function launchAction($controllerName, $actionName, $params)
    {
        //Все лежит в папке Controllers

        //Проверяем наличие файла в Controllers
        if(!file_exists(ROOTPATH.DIRECTORY_SEPARATOR.'Controllers'.DIRECTORY_SEPARATOR.$controllerName.'.php')){
            throw new Exception('Не найден контроллер:'.$controllerName.' в папке Controllers');
            
        }

        //Подключаем PHP файл...
        require_once ROOTPATH.DIRECTORY_SEPARATOR.'Controllers'.DIRECTORY_SEPARATOR.$controllerName.'.php';

        //Ищем в подключенном файле объявление под класса от класса Controllers
        if(!class_exists("Controller_".ucfirst($controllerName))){
            throw new Exception('Не найден класс внутри контроллера:'.$controllerName);
        }

        //Создаем класс и пытаемся вызвать метод $actionName;
        $controllerName = "Controller_".ucfirst($controllerName);
        $controller = new $controllerName;
        $actionName = empty($actionName) ? $this->defaultActionName : $actionName;

        if (!method_exists($controller, $actionName)){
            throw new Exception('Не найдем метод '. $actionName . 'у класса :'.$controllerName);
        }
        return $controller->$actionName($params); //передаем методу у класса параметры!!! 
        
        
    }
}