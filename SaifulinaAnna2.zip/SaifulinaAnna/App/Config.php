<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed');

return array(
    'MYSQL_HOST' => 'localhost',
    'MYSQL_USER' => 'root',
    'MYSQL_PASSWORD' => '',
    'MYSQL_DB' => 'store',
    'MYSQL_PORT' => 3306,

);

