<?php  if ( ! defined('NOACCESS')) exit('No direct script access allowed');

require_once ROOTPATH."/Router/Router.php"; //Разбор URI
require_once ROOTPATH."/App/Kernel.php"; //Ядро вызова классов 
require_once ROOTPATH."/App/Controller.php"; //Базовый класс контроллер 
require_once ROOTPATH."/App/DB.php"; //Базовый класс подключения к базе данных 


//Главный класс со статическими данными 
class App

{
        
    public static $router;
    
    public static $db;
    
    public static $kernel;
    
    public static function init($config)
    {
        //Создаем ядро и соединение с БД
        static::$router = new Router();
        static::$kernel = new Kernel();
        static::$db = new Db($config);
        
    }
    
    public static function loadClass ($className)
    {
        
        $className = str_replace('\\', DIRECTORY_SEPARATOR, $className);
        require_once ROOTPATH.DIRECTORY_SEPARATOR.$className.'.php';
        
    }
    
    public function handleException (Throwable $e)
    {
        
        if($e instanceof \App\Exceptions\InvalidRouteException) {
            echo static::$kernel->launchAction('Error', 'error404', [$e]);
        }else{
            echo static::$kernel->launchAction('Error', 'error500', [$e]);  
        }
        
    }
    
}